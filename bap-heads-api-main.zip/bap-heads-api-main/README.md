# bap-heads-api

API for fetching data for Bap Heads OSRS clan
